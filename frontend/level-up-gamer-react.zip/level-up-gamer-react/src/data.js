// src/data.js
export const cuponesValidos = [
  { codigo: "DESCUENTO10", porcentaje: 10 },
  { codigo: "GAMER20", porcentaje: 20 },
];
