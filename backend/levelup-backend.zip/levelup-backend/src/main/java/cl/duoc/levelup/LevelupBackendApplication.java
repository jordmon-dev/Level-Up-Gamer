package cl.duoc.levelup;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LevelupBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(LevelupBackendApplication.class, args);
	}

}
